# Magic spell to have us find overviewer_core
import sys
import os
import os.path
sys.path.insert(0, os.path.join(os.path.split(__file__)[0], '..'))
