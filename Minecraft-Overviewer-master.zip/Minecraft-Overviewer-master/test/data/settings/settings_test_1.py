worlds['test'] = "test/data/settings/test_world"

renders["myworld"] = { 
    "title": "myworld title",
    "world": "test",
    "rendermode": normal,
    "northdirection": "upper-left",
}

renders["otherworld"] = {
    "title": "otherworld title",
    "world": "test",
    "rendermode": normal,
    "bgcolor": "#ffffff"
}

outputdir = "/tmp/fictional/outputdir"
