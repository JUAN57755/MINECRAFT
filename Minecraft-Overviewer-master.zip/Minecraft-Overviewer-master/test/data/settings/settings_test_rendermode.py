worlds['test'] = "test/data/settings/test_world"

renders["world"] = { 
    "world": "test", 
    "title": "myworld title",
    "rendermode": "bad_rendermode",
    "northdirection": "upper-left",
}

outputdir = "/tmp/fictional/outputdir"
